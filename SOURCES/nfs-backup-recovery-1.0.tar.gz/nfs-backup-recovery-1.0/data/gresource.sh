#! /bin/sh
glib-compile-resources --target=./src/nfs-backup-recovery-resource.c --generate-source data/nfs.gresource.xml
glib-compile-resources --target=./src/nfs-backup-recovery-resource.h --generate-header data/nfs.gresource.xml