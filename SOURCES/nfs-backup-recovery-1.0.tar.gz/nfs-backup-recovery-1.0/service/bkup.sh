#!/bin/bash
/usr/bin/xinit /usr/bin/bkup-windowmanager  /usr/bin/nfs-backup-recovery  -- /usr/bin/Xorg :9 -ac -nolisten tcp
exit 0
