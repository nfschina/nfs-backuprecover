//
// Created by zhangtao on 19-12-12.
// Email: zhangtao@cpu-os.ac.cn
//

#ifndef __NFS_IMAGE_ITEM_H__
#define __NFS_IMAGE_ITEM_H__

#include "nfs-backup-recovery-private.h"
#include <glib-object.h>
#include <gio/gio.h>
#include <gtk/gtk.h>

#define NFS_TYPE_IMAGE_ITEM (nfs_image_item_get_type())
#define NFS_IMAGE_ITEM(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),NFS_TYPE_IMAGE_ITEM,NfsImageItem))
#define NFS_IS_IMAGE_ITEM(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj),NFS_TYPE_IMAGE_ITEM))
#define NFS_IMAGE_ITEM_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST((klass),NFS_TYPE_IMAGE_ITEM,NfsImageItemClass))
#define NFS_IS_IMAGE_ITEM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((obj),NFS_TYPE_IMAGE_ITEM))
#define NFS_IMAGE_ITEM_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS((obj),CDOS_TYPE_IMAGE_ITEM,NfsImageItemClass))

typedef struct _NfsImageItem NfsImageItem;
typedef struct _NfsImageItemPrivate NfsImageItemPrivate;
typedef struct _NfsImageItemClass NfsImageItemClass;

struct _NfsImageItem
{
    GtkListBoxRow parent;
    NfsImageItemPrivate *priv;
};

struct _NfsImageItemClass
{
    GtkListBoxRowClass parent_class;
};

GType	nfs_image_item_get_type (void);
NfsImageItem *
nfs_image_item_new (GtkListBox *list_box, GFile *file, MenuEntryType entry_type);
void
nfs_image_item_update_index (NfsImageItem *self);
void
nfs_image_item_set_menu_entry_type (NfsImageItem *self, MenuEntryType entry_type);
void
nfs_image_item_select (NfsImageItem *self);
void
nfs_image_item_unselect (NfsImageItem *self);
void
nfs_image_item_select_toggle (NfsImageItem *self);
gboolean
nfs_image_item_is_selected (NfsImageItem *self);
GFile *
nfs_image_item_get_file (NfsImageItem *self);
GFileInfo *
nfs_image_item_get_file_info (NfsImageItem *self);
gboolean 
nfs_image_item_is_editing (NfsImageItem *self);

#endif //__NFS_IMAGE_ITEM_H__
