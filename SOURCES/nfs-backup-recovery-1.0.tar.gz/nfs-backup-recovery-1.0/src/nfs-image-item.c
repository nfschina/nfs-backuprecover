//
// Created by zhangtao on 19-12-12.
// Email: zhangtao@cpu-os.ac.cn
//
#include <config.h>
#include <math.h>
#include <glib.h>
#include <glib/gi18n.h>
#include <locale.h>
#include <cairo.h>

#include "nfs-image-item.h"
#include "nfs-backup-recovery-resource.h"

struct _NfsImageItemPrivate
{
    gboolean        lock;
    GtkListBox      *list_box;
    GFile           *file;
    GFileInfo       *file_info;
    GtkWidget       *label_index;
    GtkWidget       *label_title;
    GtkWidget       *label_subtitle;
    GtkWidget       *entry_title;
    GtkWidget       *button_edit;
    GtkWidget       *button_lock;
    GtkWidget       *button_checked;

    GtkStyleContext *entry_style_context;

    GPermission     *permission;
    MenuEntryType   entry_type;
};

//must after struct _NfsImageItemPrivate;
G_DEFINE_TYPE_WITH_PRIVATE (NfsImageItem, nfs_image_item, GTK_TYPE_LIST_BOX_ROW);

static void nfs_image_item_init (NfsImageItem *self);
static void nfs_image_item_class_init (NfsImageItemClass *klass);
static void nfs_image_item_dispose (GObject *object);
static void nfs_image_item_finalize (GObject *object);
static void
nfs_image_item_set_file (NfsImageItem *self, GFile *file);

GFileInfo *
file_query_info (GFile *file)
{
    GFileInfo *file_info = NULL;
    file_info = g_file_query_info (file,
                                    FILE_INFO_ATTRS,
                                    G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                    NULL,
                                    NULL);
    return file_info;
}

static gboolean
item_file_rename_verify (GtkListBox *list_box, const gchar *new_name, gchar **reason)
{
    GList *children, *items;
    GFileInfo       *file_info;
    const gchar     *display_name;
    gboolean        success = FALSE;
    const gchar     *pattern;
    pattern = "[\\w\\-\\:]+$";
    if (!new_name)
    {
        *reason = _("The name is empty.");
        return success;
    }
    if (g_regex_match_simple (pattern, new_name, G_REGEX_CASELESS, G_REGEX_MATCH_ANCHORED) == FALSE)
    {
        *reason = _("The name is not in conformity.");
        return success;
    }

    children = gtk_container_get_children (GTK_CONTAINER (list_box));
    items = children;
    while (items)
    {
        GtkWidget *item = items->data;
        file_info = nfs_image_item_get_file_info (NFS_IMAGE_ITEM (item));
        if (file_info)
        {
            display_name = g_file_info_get_display_name (file_info);
            if (g_strcmp0 (new_name, display_name) == 0)
            {
                success = FALSE;
                *reason = _("The name has existed, please change another one.");
                goto out;
            } else {
                success = TRUE;
            }
        }
        items = items->next;
    }

out:
    g_list_free (children);
    if (success)
    {
        *reason = NULL;
    }
    return success;
}

static void
item_file_rename_cb (GObject *source_object,
		             GAsyncResult *res,
		             gpointer user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    //NfsImageItemPrivate *priv = self->priv;
    GFile *new_file = NULL;
	GError *error = NULL;
    new_file = g_file_set_display_name_finish (G_FILE (source_object),
						                       res, 
                                               &error);
    if (error)
    {
        g_warning ("\n%s:%s;\n", __func__, error->message);
        g_error_free (error);
        return ;
    }
    if (new_file)
    {
        nfs_image_item_set_file (self, new_file);
        nfs_backup_recovery_set_notice (NOTICE_NOMAL, NULL);
    }
}

static gboolean
item_file_rename (NfsImageItem *self, const gchar *new_name)
{
    NfsImageItemPrivate *priv = self->priv;
    const gchar *old_file_name;
    gchar *new_file_name;

    if (!new_name)
    {
        return FALSE;
    }

    old_file_name = g_file_info_get_display_name (priv->file_info);
    new_file_name = g_strdup_printf ("%s-%d-%s", IMAGE_PREFIX, priv->lock, new_name);
    if (g_strcmp0 (old_file_name, new_file_name) == 0)
    {
        g_free (new_file_name);
        return FALSE;
    }
    
    g_file_set_display_name_async (priv->file, 
                                   new_file_name, 
                                   G_PRIORITY_DEFAULT, 
                                   NULL, 
                                   item_file_rename_cb, 
                                   self);
    g_free (new_file_name);
    return TRUE;
}

static void
nfs_image_item_update_lock (NfsImageItem *self)
{
    NfsImageItemPrivate *priv = self->priv;
    gboolean row_selectable = TRUE;

    g_permission_impl_update (priv->permission, priv->lock, TRUE, TRUE);
    gtk_widget_set_sensitive (priv->button_edit, !priv->lock);

    if (priv->entry_type == MENU_ENTRY_IMAGES_MANAGE)
    {
        row_selectable = !priv->lock;
        gtk_widget_set_sensitive (priv->button_checked, !priv->lock);
    }
    else if (priv->entry_type == MENU_ENTRY_RECOVERY)
    {
        row_selectable = TRUE;
        gtk_widget_set_sensitive (priv->button_checked, TRUE);
    }
    gtk_list_box_row_set_selectable (GTK_LIST_BOX_ROW (self), row_selectable);
    if (row_selectable)
    {
        gtk_list_box_select_row (priv->list_box, GTK_LIST_BOX_ROW (self));
    }
}

static void
nfs_image_item_update_subtitle (NfsImageItem *self)
{
    NfsImageItemPrivate *priv = self->priv;
    guint64 time;
    GDateTime *date_time;
    gchar *time_str, *subtitle;

    time = g_file_info_get_attribute_uint64 (priv->file_info, G_FILE_ATTRIBUTE_TIME_MODIFIED);
    date_time = g_date_time_new_from_unix_local (time);
    time_str = g_date_time_format (date_time, "%Y/%m/%d %H:%M");
    subtitle = g_strdup_printf ("%s: %s", _("Created time"), time_str);
    gtk_label_set_text (GTK_LABEL (priv->label_subtitle), subtitle);

    g_date_time_unref (date_time);
    g_free (time_str);
    g_free (subtitle);
}

//display name just like: image-1-xxx(lock), or image-0-xxx(unlock), or image-xxx(unlock);
static gchar **
nfs_image_item_parse_title (GFileInfo *file_info)
{
    gchar **parts = NULL;
    const gchar *display_name = g_file_info_get_display_name (file_info);
    if (display_name == NULL)
    {
        goto out;
    }
    parts = g_strsplit (display_name, "-", 3);
    if (parts && g_strcmp0 (parts[0], IMAGE_PREFIX) == 0)
    {
        return parts;
    }
out:
    g_strfreev (parts);
    return NULL;
}

static gboolean
nfs_image_item_check_file (GFile *file)
{
    gchar **parse_title;
    GFileInfo *file_info;
    file_info = file_query_info (file);
    if (file_info)
    {
        parse_title = nfs_image_item_parse_title (file_info);
        if (parse_title)
        {
            g_strfreev (parse_title);
            g_object_unref (file_info);
            return TRUE;
        }
        g_object_unref (file_info);
    }
    return FALSE;
}

static void
nfs_image_item_update_title (NfsImageItem *self)
{
    NfsImageItemPrivate *priv = self->priv;
    gchar *title;
    gchar **parse_title;
    gint len = 0;
    parse_title = nfs_image_item_parse_title (priv->file_info);
    if (parse_title)
    {
        len = g_strv_length (parse_title);
        if (len == 3 && g_strcmp0 (parse_title[1], "1") == 0)
        {
            priv->lock = TRUE;
        }
        if (len == 2)
        {
            title = parse_title[1];
        } else {
            title = parse_title[2];
        }
        gtk_label_set_text (GTK_LABEL (priv->label_title), title);
        g_strfreev (parse_title);
    }
}

static void
nfs_image_item_update_info (NfsImageItem *self)
{
    nfs_image_item_update_title (self);
    nfs_image_item_update_subtitle (self);
    nfs_image_item_update_lock (self);
}

static void
nfs_image_item_set_file (NfsImageItem *self, GFile *file)
{
    NfsImageItemPrivate *priv = self->priv;
    if (file)
    {
        if (priv->file_info)
        {
            g_object_unref (priv->file_info);
        }
        if (priv->file)
        {
            g_object_unref (priv->file);
        }
        priv->file = file;
        priv->file_info = file_query_info (file);
        nfs_image_item_update_info (self);
    }
}

static void
nfs_image_item_setup (NfsImageItem *self, GtkListBox *list_box, MenuEntryType entry_type)
{
    NfsImageItemPrivate *priv = self->priv;
    priv->list_box = list_box;

    gtk_widget_hide (priv->entry_title);
    nfs_image_item_set_menu_entry_type (self, entry_type);
}

static void
entry_edit_done (NfsImageItem *self, gboolean accept)
{
    NfsImageItemPrivate *priv = self->priv;
    const gchar *new_name;
    gboolean verify = FALSE;
    gboolean entry_exit = FALSE;
    gchar *reason = NULL;
    if (accept)
    {
        new_name = gtk_entry_get_text (GTK_ENTRY (priv->entry_title));
        verify = item_file_rename_verify (priv->list_box, new_name, &reason);
        if (verify)
        {
            item_file_rename (self, new_name);
            entry_exit = TRUE;
        } else {
            entry_exit = FALSE;
            nfs_backup_recovery_set_notice (NOTICE_WARNING, reason);
            gtk_style_context_add_class (priv->entry_style_context, "entry-warning");
        }
    } else {
        entry_exit = TRUE;
    }

    if (entry_exit)
    {
        gtk_widget_show (priv->button_edit);
        gtk_widget_show (priv->label_title);
        gtk_widget_hide (priv->entry_title);
        gtk_widget_grab_focus (GTK_WIDGET (self));
        nfs_backup_recovery_set_notice (NOTICE_NOMAL, NULL);
        gtk_style_context_remove_class (priv->entry_style_context, "entry-warning");
    }
}


static void
list_item_refrush_each_cb (GtkWidget *widget, gpointer data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (data);
    if (GTK_WIDGET (self) != widget)
    {
        nfs_image_item_unselect (NFS_IMAGE_ITEM (widget));
    }
}

static void
list_box_refrush (NfsImageItem *self)
{
    NfsImageItemPrivate *priv = self->priv;
    gtk_container_foreach (GTK_CONTAINER (priv->list_box),
                          (GtkCallback)list_item_refrush_each_cb,
                          self);
    
}

static void
button_checked_toggled_cb (GtkToggleButton *togglebutton, gpointer user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    NfsImageItemPrivate *priv = self->priv;
    gboolean active = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (togglebutton));
    if (gtk_widget_get_sensitive (priv->button_checked))
    {
        if (active)
        {
            if (priv->entry_type == MENU_ENTRY_RECOVERY)
            {
                list_box_refrush (self);
            }
            gtk_list_box_select_row (priv->list_box, GTK_LIST_BOX_ROW (self));
        }
        g_signal_emit_by_name (GTK_LIST_BOX (priv->list_box), "selected-rows-changed", NULL);
    }
}

static void
lock_button_clicked_cb (GtkButton *widget, gpointer user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    NfsImageItemPrivate *priv = self->priv;
    const gchar *name = NULL;

    gboolean allowed = g_permission_get_allowed (priv->permission);
    priv->lock = !allowed;
    nfs_image_item_unselect (self);
    nfs_image_item_update_lock (self);

    name = gtk_label_get_text (GTK_LABEL (priv->label_title));
    item_file_rename (self, name);
}

static void
button_edit_clicked_cb (GtkButton *widget, gpointer user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    NfsImageItemPrivate *priv = self->priv;
    const gchar *title = gtk_label_get_text (GTK_LABEL (priv->label_title));
    gtk_widget_hide (priv->button_edit);
    gtk_widget_hide (priv->label_title);
    gtk_widget_show (priv->entry_title);
    gtk_entry_set_text (GTK_ENTRY (priv->entry_title), title);
    gtk_entry_grab_focus_without_selecting (GTK_ENTRY (priv->entry_title));
    nfs_backup_recovery_set_notice (NOTICE_NOMAL, _("The image name support characters."));
    gtk_list_box_select_row (priv->list_box, GTK_LIST_BOX_ROW (self));
}

static void
entry_title_activate_cb (GtkEntry *entry, gpointer user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    entry_edit_done (self, TRUE);
}

static gboolean 
entry_title_focus_out_event_cb (GtkWidget *widget,
                                GdkEvent  *event,
                                gpointer   user_data)
{
    NfsImageItem *self = NFS_IMAGE_ITEM (user_data);
    entry_edit_done (self, FALSE);
    return FALSE;
}

static void
nfs_image_item_init (NfsImageItem *self)
{
    NfsImageItemPrivate *priv;
    priv = self->priv = nfs_image_item_get_instance_private (self);
    gtk_widget_init_template (GTK_WIDGET (self));

    priv->entry_type = MENU_ENTRY_NONE;
    priv->lock = FALSE;

    priv->permission = g_simple_permission_new (FALSE);
    gtk_lock_button_set_permission (GTK_LOCK_BUTTON (priv->button_lock), priv->permission);

    priv->entry_style_context = gtk_widget_get_style_context (priv->entry_title);
}

static void
nfs_image_item_class_init (NfsImageItemClass *klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
    GtkWidgetClass *widget_class = GTK_WIDGET_CLASS (klass);

    gobject_class->dispose = nfs_image_item_dispose;
    gobject_class->finalize = nfs_image_item_finalize;

    GBytes *bytes = NULL;
    GResource *resource = nfs_get_resource ();
    if (resource)
    {
        bytes = g_resource_lookup_data (resource, "/org/nfs/backup-recovery/data/item.ui", 0, NULL);
        gtk_widget_class_set_template (widget_class, bytes);
        g_resource_unref (resource);
        g_bytes_unref (bytes);
    }

    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, label_index);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, label_title);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, entry_title);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, button_edit);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, label_subtitle);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, button_lock);
    gtk_widget_class_bind_template_child_private (widget_class, NfsImageItem, button_checked);
    gtk_widget_class_bind_template_callback (widget_class, button_checked_toggled_cb);
    gtk_widget_class_bind_template_callback (widget_class, lock_button_clicked_cb);
    gtk_widget_class_bind_template_callback (widget_class, button_edit_clicked_cb);
    gtk_widget_class_bind_template_callback (widget_class, entry_title_activate_cb);
    gtk_widget_class_bind_template_callback (widget_class, entry_title_focus_out_event_cb);  
}

static void
nfs_image_item_dispose (GObject *object)
{
    NfsImageItemPrivate *priv = NFS_IMAGE_ITEM (object)->priv;
    if (priv->file_info)
    {
        g_object_unref (priv->file_info);
        priv->file_info = NULL;
    }
    if (priv->file)
    {
        g_object_unref (priv->file);
        priv->file = NULL;
    }
    if (priv->permission)
    {
        gtk_lock_button_set_permission (GTK_LOCK_BUTTON (priv->button_lock), NULL);
        g_object_unref (priv->permission);
        priv->permission = NULL;
    }

    G_OBJECT_CLASS (nfs_image_item_parent_class)->dispose (object);
}

static void
nfs_image_item_finalize (GObject *object)
{
    NfsImageItemPrivate *priv = NFS_IMAGE_ITEM (object)->priv;


    G_OBJECT_CLASS (nfs_image_item_parent_class)->finalize (object);
}

NfsImageItem *
nfs_image_item_new (GtkListBox *list_box, GFile *file, MenuEntryType entry_type)
{
    g_return_val_if_fail (GTK_IS_LIST_BOX (list_box), NULL);
    g_return_val_if_fail (G_IS_FILE (file), NULL);
    NfsImageItem *image_item = NULL;

    if (nfs_image_item_check_file (file))
    {
        image_item = g_object_new (NFS_TYPE_IMAGE_ITEM, NULL);
        g_object_ref (file);

        nfs_image_item_setup (image_item, list_box, entry_type);
        nfs_image_item_set_file (image_item, file);
    }
    return image_item;
}

void
nfs_image_item_update_index (NfsImageItem *self)
{
    g_return_if_fail (NFS_IS_IMAGE_ITEM (self));
    NfsImageItemPrivate *priv = self->priv;
    gint index;
    gchar *index_str;

    index = gtk_list_box_row_get_index (GTK_LIST_BOX_ROW (self));
    index_str = g_strdup_printf ("%d", index + 1);

    gtk_label_set_text (GTK_LABEL (priv->label_index), index_str);
    g_free (index_str);
}

void
nfs_image_item_set_menu_entry_type (NfsImageItem *self, MenuEntryType entry_type)
{
    g_return_if_fail (NFS_IS_IMAGE_ITEM (self));
    NfsImageItemPrivate *priv = self->priv;
    if (priv->entry_type == entry_type)
    {
        return ;
    }

    priv->entry_type = entry_type;
    if (priv->entry_type == MENU_ENTRY_IMAGES_MANAGE)
    {
        gtk_widget_show (priv->button_lock);
        gtk_widget_show (priv->button_edit);
    } else {
        gtk_widget_hide (priv->button_lock);
        gtk_widget_hide (priv->button_edit);
    }
    nfs_image_item_update_lock (self);
}

void
nfs_image_item_select (NfsImageItem *self)
{
    g_return_if_fail (NFS_IS_IMAGE_ITEM (self));
    NfsImageItemPrivate *priv = self->priv;
    if (gtk_widget_get_sensitive (priv->button_checked))
    {
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (priv->button_checked), TRUE);
    }
}

void
nfs_image_item_unselect (NfsImageItem *self)
{
    g_return_if_fail (NFS_IS_IMAGE_ITEM (self));
    NfsImageItemPrivate *priv = self->priv;
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (priv->button_checked), FALSE);
}

void
nfs_image_item_select_toggle (NfsImageItem *self)
{
    g_return_if_fail (NFS_IS_IMAGE_ITEM (self));
    NfsImageItemPrivate *priv = self->priv;
    gboolean is_active = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (priv->button_checked));
    if (gtk_widget_get_sensitive (priv->button_checked))
    {
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (priv->button_checked), !is_active);
    }
}

gboolean
nfs_image_item_is_selected (NfsImageItem *self)
{
    g_return_val_if_fail (NFS_IS_IMAGE_ITEM (self), FALSE);
    NfsImageItemPrivate *priv = self->priv;
    return gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (priv->button_checked));
}

GFile *
nfs_image_item_get_file (NfsImageItem *self)
{
    g_return_val_if_fail (NFS_IS_IMAGE_ITEM (self), NULL);
    NfsImageItemPrivate *priv = self->priv;
    return priv->file;
}

GFileInfo *
nfs_image_item_get_file_info (NfsImageItem *self)
{
    g_return_val_if_fail (NFS_IS_IMAGE_ITEM (self), NULL);
    NfsImageItemPrivate *priv = self->priv;
    return priv->file_info;
}

gboolean 
nfs_image_item_is_editing (NfsImageItem *self)
{
    g_return_val_if_fail (NFS_IS_IMAGE_ITEM (self), FALSE);
    NfsImageItemPrivate *priv = self->priv;
    return gtk_widget_get_visible (GTK_WIDGET (priv->entry_title));
}