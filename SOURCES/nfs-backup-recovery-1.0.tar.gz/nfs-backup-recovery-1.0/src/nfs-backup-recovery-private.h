#ifndef __NFS_BACKUP_RECOVERY_PRIVATE_H__
#define __NFS_BACKUP_RECOVERY_PRIVATE_H__

#include <gtk/gtk.h>
#include <gio/gio.h>

#define W(b,x) GTK_WIDGET (gtk_builder_get_object (b, x))

//#define IMAGE_DIR           "/media/nfs_dev_sda13/test/image"
//#define FS_DIR              "/media/nfs_dev_sda13"
//#define IMAGE_PREFIX        "image"
#define IMAGE_DIR           "/home/partimag"
#define FS_LOG_DIR          "/media"
#define FS_DIR              "/mnt"
#define IMAGE_PREFIX        "image"
#define FILE_INFO_ATTRS     "standard::*,time::*"
#define FILE_SYSTEM_ATTRS   "standard::*,filesystem::*"

#define DEVICE_FREE_SPACE_THRESHOLD     5.0     //GB;
#define LOG_FREE_SPACE_THRESHOLD        0.1     //GB;

typedef enum
{
    MENU_ENTRY_REBOOT,
    MENU_ENTRY_BACKUP,
    MENU_ENTRY_RECOVERY,
    MENU_ENTRY_IMAGES_MANAGE,
    MENU_ENTRY_RESTORE_FACTORY_SETTINGS,
    MENU_ENTRY_SEPARATOR,
    MENU_ENTRY_BACKUP_FACTORY_SETTINGS,
    MENU_ENTRY_NONE
} MenuEntryType;

typedef enum 
{
    NOTICE_NOMAL,
    NOTICE_WARNING
} NoticeType;

typedef struct {
    MenuEntryType   entry_type;
    gchar           *name;
    const   gchar   *icon;
} MenuEntry;

void
nfs_backup_recovery_set_notice (NoticeType notice_type, gchar *notice);

#endif //__NFS_BACKUP_RECOVERY_PRIVATE_H__
