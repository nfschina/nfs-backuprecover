//
// Created by zhangtao on 19-12-12.
// Email: zhangtao@cpu-os.ac.cn
//
/* nemo-print -- Nemo File Printing Extension
 *
 * Sebastien Estienne <sebastien.estienne@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street - Suite 500, Boston, MA 02110-1335, USA.
 *
 * (C) Copyright 2005 Ethium, Inc.
 * (C) Copyright 2016-2018 CPU and Fundamental Software Research Center,
 *     Chinese Academy of Sciences.
 */

#include <config.h>
#include <glib/gi18n-lib.h>
#include <gio/gio.h>
#include <gtk/gtk.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

#include "nfs-backup-recovery.h"

static GtkApplication * app = NULL;
static NfsBackupRecovery *back_recovery = NULL;

static void
application_on_startup (GApplication *application,
                        gpointer user_data)
{
    back_recovery = nfs_backup_recovery_run (app);
    if (!back_recovery)
    {
        g_error ("nfs backup recovery occurred some error.\n");
    }
}

static int
application_on_command_line (GApplication  *application,
                             GApplicationCommandLine  *command_line,
                             gpointer user_data)
{
    int argc;
    char **argv;

    argv = g_application_command_line_get_arguments (command_line, &argc);

    return 0;
}

static void
application_on_window_removed (GtkApplication *application,
                               GtkWindow      *window,
                               gpointer        user_data)
{

}

static void
application_exit (int sig)
{
    if (back_recovery)
    {
        g_object_unref (back_recovery);
        back_recovery = NULL;
    }
    if (app)
    {
        g_application_quit (G_APPLICATION (app));
        app = NULL;
    }
}

static void
app_set_theme (const gchar *path)
{
    GdkScreen *screen;
    GtkCssProvider *provider;
    screen = gdk_screen_get_default ();
    provider = gtk_css_provider_get_default ();
    gtk_css_provider_load_from_path (provider, path, NULL);
    gtk_style_context_add_provider_for_screen (screen, 
                                               provider, 
                                               GTK_STYLE_PROVIDER_PRIORITY_USER);
}

int
main (int argc, char **argv)
{
    setlocale (LC_ALL, "");
    bindtextdomain (GETTEXT_PACKAGE, NFS_BACKUP_RECOVERY_LOCALEDIR);
    bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
    textdomain (GETTEXT_PACKAGE);

    gint status;
    gtk_init (&argc, &argv);
    signal (SIGINT, application_exit);

    
    app = gtk_application_new (NULL, G_APPLICATION_HANDLES_COMMAND_LINE);
    g_signal_connect (app, 
                    "startup",
                    G_CALLBACK (application_on_startup), 
                    NULL);
    g_signal_connect (app, 
                    "command-line",
                    G_CALLBACK (application_on_command_line), 
                    NULL);
    g_signal_connect (app,
                    "window-removed",
                    G_CALLBACK (application_on_window_removed), 
                    NULL);
    app_set_theme (DATA_DIR "/style.css");
    status = g_application_run (G_APPLICATION (app), argc, argv);
    application_exit (0);
    
    return status;
}