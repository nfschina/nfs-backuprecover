#ifndef __RESOURCE_nfs_H__
#define __RESOURCE_nfs_H__

#include <gio/gio.h>

extern GResource *nfs_get_resource (void);
#endif
