//
// Created by zhangtao on 19-12-12.
// Email: zhangtao@cpu-os.ac.cn
//
#include <unistd.h>
#include <stdlib.h>
#include <config.h>
#include <math.h>
#include <glib.h>
#include <glib/gi18n.h>
#include <locale.h>
#include <cairo.h>

#include "nfs-backup-recovery.h"
#include "nfs-image-item.h"

#define COMMAND_REBOOT  "sudo reboot"
#define COMMAND_DELAY_REBOOT  "sudo bash -c 'sleep 5; reboot'"
#define COMMAND_BACKUP  "sudo bash /mnt/efi-script/backup-recent-image"
#define COMMAND_RECOVERY    "sudo bash /mnt/efi-script/recover-recent-image"
#define COMMAND_RESTORE_FACTORY_SETTINGS    "sudo bash /mnt/efi-script/recover-init-image-factory"
#define COMMAND_BACKUP_FACTORY_SETTINGS    "sudo bash /mnt/efi-script/backup-init-image"
#define IMAGE_FACTORY_SETTINGS  "init-image"

#define NFS_BACKUP_RECOVERY_GET_PRIVATE(obj)      \
(G_TYPE_INSTANCE_GET_PRIVATE((obj), NFS_TYPE_BACKUP_RECOVERY, NfsBackupRecoveryPrivate))

G_DEFINE_TYPE (NfsBackupRecovery, nfs_backup_recovery, G_TYPE_OBJECT);

static MenuEntry menu_enties[] = {
    {MENU_ENTRY_REBOOT, N_("Reboot"), "reboot.png"},
    {MENU_ENTRY_BACKUP, N_("Backup"), "backup.png"},
    {MENU_ENTRY_RECOVERY, N_("Recovery"), "recovery.png"},
    {MENU_ENTRY_IMAGES_MANAGE, N_("Image manage"), "images-manage.png"},
    {MENU_ENTRY_SEPARATOR, "separator", NULL},
    {MENU_ENTRY_RESTORE_FACTORY_SETTINGS, N_("Restore factory settings"), "restore-factory-settings.png"},
    {MENU_ENTRY_NONE, NULL, NULL}
};

struct _NfsBackupRecoveryPrivate
{
    GtkApplication  *application;
    GtkBuilder      *builder;
    GtkWidget       *window;
    MenuEntryType   selected_entry_type;
    GFile           *image_dir;
    GFileMonitor    *monitor;
    GFileEnumerator *enumerator;
    GtkWidget       *dialog_window;

    GFile           *fs_file;
    gboolean        space_full;
    gboolean        log_space_full;

    gchar           *image;
    gchar           *command;
    int             cmd_result;
    int             cmd_finished;
    gboolean        working;
    uint            timer;
};

static NfsBackupRecovery *backup_recovery = NULL;

static void nfs_backup_recovery_init (NfsBackupRecovery *self);
static void nfs_backup_recovery_class_init (NfsBackupRecoveryClass *klass);
static void nfs_backup_recovery_dispose (GObject *object);
static void nfs_backup_recovery_finalize (GObject *object);

static void
subtitle_update_datetime (NfsBackupRecovery *self, NfsImageItem *item);
static void
menu_action_restore_factory_settings (NfsBackupRecovery *self);
static void
items_list_reset (NfsBackupRecovery *self);
static void
items_list_setup (NfsBackupRecovery *self);
static GList *
itemes_list_get_selected_rows (NfsBackupRecovery *self, int selected);
static void
check_device_space (NfsBackupRecovery *self, gboolean show_notice);
static GtkWidget *
menu_get_entry_item (NfsBackupRecovery *self, MenuEntryType entry_type);
static void
freeze_all_menu_entries (NfsBackupRecovery *self);
static void
check_log_space (NfsBackupRecovery *self);

static void
menu_action_exit (gboolean res)
{
    if (res)
    {
        exit (0);
    }
}

static void
confirm_dialog_on_response (GtkDialog *dialog,
                            gint       response_id,
                            gpointer   user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget   *entry_item;

    if (response_id == GTK_RESPONSE_OK)
    {
        menu_action_restore_factory_settings (self);
    } else {
        entry_item = menu_get_entry_item (self, MENU_ENTRY_RESTORE_FACTORY_SETTINGS);
        gtk_widget_grab_focus (entry_item);
    }
}

static void
confirm_dialog_run (NfsBackupRecovery *self, gchar *message, gchar *secondary_text)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *dialog;
    GtkWidget   *entry_item;

    dialog = gtk_message_dialog_new (GTK_WINDOW (priv->window),
                                    GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                    GTK_MESSAGE_INFO,
                                    GTK_BUTTONS_OK_CANCEL,
                                    message);
    priv->dialog_window = dialog;
    if (secondary_text)
    {
        gtk_message_dialog_format_secondary_text (GTK_MESSAGE_DIALOG (dialog), secondary_text);
    }
    gtk_window_set_resizable (GTK_WINDOW(dialog), FALSE);
    gtk_window_set_titlebar (GTK_WINDOW(dialog), NULL);
    g_object_set_property (dialog, "deletable", FALSE);
    g_signal_connect (dialog,
                      "response",
                      G_CALLBACK (confirm_dialog_on_response),
                      self);
    gtk_dialog_run (GTK_DIALOG (dialog));
    entry_item = menu_get_entry_item (self, MENU_ENTRY_RESTORE_FACTORY_SETTINGS);
    gtk_widget_grab_focus (entry_item);

    gtk_widget_destroy (GTK_WIDGET (dialog));
    priv->dialog_window = NULL;
}

static GtkWidget *
menu_get_entry_item (NfsBackupRecovery *self, MenuEntryType entry_type)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *menu_box, *expected_item = NULL;
    GList *entry_items, *children;
    MenuEntry *entry;
    menu_box = W (priv->builder, "menu-box");
    entry_items = gtk_container_get_children (GTK_CONTAINER (menu_box));
    children = entry_items;
    while (children != NULL)
    {
        GtkWidget *item = children->data;
        entry = g_object_get_data (G_OBJECT (item), "entry");
        if (entry && entry->entry_type == entry_type)
        {
            expected_item = item;
            break;
        }
        children = children->next;
    }
    g_list_free (entry_items);
    return expected_item;
}

static void
menu_entry_item_freeze (GtkWidget *entry_item)
{
    gtk_widget_set_sensitive (entry_item, FALSE);
    gtk_list_box_row_set_activatable (GTK_LIST_BOX_ROW (entry_item), FALSE);
    gtk_list_box_row_set_selectable (GTK_LIST_BOX_ROW (entry_item), FALSE);
    gtk_list_box_row_set_selectable (GTK_LIST_BOX_ROW (entry_item), FALSE);
}

static void
menu_entry_item_unfreeze (GtkWidget *entry_item)
{
    gtk_widget_set_sensitive (entry_item, TRUE);
    gtk_list_box_row_set_activatable (GTK_LIST_BOX_ROW (entry_item), TRUE);
    gtk_list_box_row_set_selectable (GTK_LIST_BOX_ROW (entry_item), TRUE);
    gtk_list_box_row_set_selectable (GTK_LIST_BOX_ROW (entry_item), TRUE);
}

static void
notice_set_content (NfsBackupRecovery *self, NoticeType notice_type, gchar *content)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *notice_box = W (priv->builder, "notice-box");
    GtkWidget *notice_detail = W (priv->builder, "notice-detail");
    GtkStyleContext     *notice_style;
    notice_style = gtk_widget_get_style_context (notice_box);
    if (notice_type == NOTICE_WARNING)
    {
        gtk_style_context_add_class (notice_style, "label-warning");
    } else {
        gtk_style_context_remove_class (notice_style, "label-warning");
    }

    gtk_widget_show (notice_box);
    gtk_label_set_text (GTK_LABEL (notice_detail), content);
}

static void
switch_to_menus (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *stack = W (priv->builder, "stack-content");
    GtkWidget *menu_box = W (priv->builder, "menu-box");
    GtkWidget *progress_box = W (priv->builder, "progress-box");
    gtk_stack_set_visible_child_name (GTK_STACK (stack), "menu");
    gtk_widget_set_vexpand (stack, FALSE);
    gtk_widget_hide (progress_box);

    GtkListBoxRow *selected = gtk_list_box_get_selected_row (GTK_LIST_BOX (menu_box));
    if (selected)
    {
        gtk_widget_grab_focus (GTK_WIDGET (selected));
    }

    if (priv->space_full)
    {
        notice_set_content (self, NOTICE_WARNING, _("Device space will be full, you'd better delete some useless images"));
    } else {
        notice_set_content (self, NOTICE_NOMAL, NULL);
    }
}

static void 
items_list_update (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    GList *items, *children;
    children = gtk_container_get_children (GTK_CONTAINER (items_list));
    items = children;
    while (items != NULL)
    {
        GtkWidget *item = items->data;
        gtk_container_remove(GTK_CONTAINER (items_list), GTK_WIDGET (item));
        items = items->next;
    }
    g_list_free (children);
    subtitle_update_datetime (self, NULL);
    items_list_setup (self);
}

static void
switch_to_items (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *stack = W (priv->builder, "stack-content");
    GtkWidget *items_list = W (priv->builder, "items-list");
    GtkWidget *progress_box = W (priv->builder, "progress-box");

    gtk_stack_set_visible_child_name (GTK_STACK (stack), "items");
    gtk_widget_set_vexpand (stack, TRUE);
    gtk_widget_hide (progress_box);

    gtk_list_box_unselect_all (GTK_LIST_BOX (items_list));
    items_list_reset (self);
    GtkListBoxRow *default_item = gtk_list_box_get_row_at_index (GTK_LIST_BOX (items_list), 0);
    if (default_item)
    {
        gtk_widget_grab_focus (GTK_WIDGET (default_item));
        gtk_list_box_select_row (GTK_LIST_BOX (items_list), default_item);
    } else if ((priv->selected_entry_type == MENU_ENTRY_RECOVERY) || 
               (priv->selected_entry_type == MENU_ENTRY_IMAGES_MANAGE))
    {
        GtkWidget *button_back = W (priv->builder, "button-back");
        gtk_widget_grab_focus (button_back);
        subtitle_update_datetime (self, NULL);
        if (priv->selected_entry_type != MENU_ENTRY_BACKUP_FACTORY_SETTINGS)
            notice_set_content (self, NOTICE_WARNING, _("There is nothing available images, please backup one image."));
    }

}

static void
items_list_reset_each_cb (GtkWidget *widget, gpointer data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    nfs_image_item_unselect (NFS_IMAGE_ITEM (widget));
    nfs_image_item_set_menu_entry_type (NFS_IMAGE_ITEM (widget),
                                        priv->selected_entry_type);
}

static void
items_list_reset (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    gtk_container_foreach (GTK_CONTAINER (items_list),
                        (GtkCallback)items_list_reset_each_cb,
                        self);
}

static void
items_list_update_index_each_cb (GtkWidget *widget, gpointer data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (data);
    nfs_image_item_update_index (widget);
    if (gtk_list_box_row_get_index (GTK_LIST_BOX_ROW (widget)) == 0)
    {
        subtitle_update_datetime (self, NFS_IMAGE_ITEM (widget));
    }
}

static void
items_list_update_index (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    gtk_container_foreach (GTK_CONTAINER (items_list),
                           (GtkCallback)items_list_update_index_each_cb,
                           self);
}

static void
items_list_add_item (NfsBackupRecovery *self, GFile *file)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    NfsImageItem *item = nfs_image_item_new (GTK_LIST_BOX (items_list),
                                             file,
                                             priv->selected_entry_type);
    if (item)
    {
        gtk_container_add (GTK_CONTAINER (items_list), GTK_WIDGET (item));
    }
}

static void
more_files_callback (GObject *source_object,
                     GAsyncResult *res,
                     gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    GList *files, *l;
    GFileInfo *info;
    GFile  *file;
    GError *error = NULL;
    const gchar *display_name = NULL;

    files = g_file_enumerator_next_files_finish (G_FILE_ENUMERATOR (source_object),
                                                 res,
                                                 &error);
    for (l = files; l != NULL; l = l->next)
    {
        //unref the files with g_object_unref() when you're done with them
        info = l->data;
        GFileType file_type = g_file_info_get_file_type (info);
        if (file_type == G_FILE_TYPE_DIRECTORY)
        {
            file = g_file_enumerator_get_child (G_FILE_ENUMERATOR (source_object), info);
            items_list_add_item (self, file);

            //check factory settings images;
            display_name = g_file_info_get_display_name (info);
            if (g_strcmp0 (display_name, IMAGE_FACTORY_SETTINGS) == 0 && priv->log_space_full == FALSE)
            {
                GtkWidget *entry = menu_get_entry_item (self, MENU_ENTRY_RESTORE_FACTORY_SETTINGS);
                menu_entry_item_unfreeze (entry);
            }
            g_object_unref (info);
            g_object_unref (file);
        }
    }
    items_list_update_index (self);
    g_list_free (files);
}

static void
enumerate_children_cb (GObject *source_object,
                       GAsyncResult *res,
                       gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;

    GError *error = NULL;

    priv->enumerator = g_file_enumerate_children_finish (G_FILE (source_object),
                                                         res,
                                                         &error);
    if (priv->enumerator == NULL)
    {
        g_error_free (error);
        return ;
    }
    g_file_enumerator_next_files_async (priv->enumerator,
                                        100,
                                        G_PRIORITY_DEFAULT,
                                        NULL,
                                        more_files_callback,
                                        user_data);
}

static gint
items_sort_cb (GtkListBoxRow *row1,
               GtkListBoxRow *row2,
               gpointer user_data)
{
    GFileInfo *info1, *info2;
    guint time1, time2;
    info1 = nfs_image_item_get_file_info (NFS_IMAGE_ITEM (row1));
    info2 = nfs_image_item_get_file_info (NFS_IMAGE_ITEM (row2));

    time1 = g_file_info_get_attribute_uint64 (info1, G_FILE_ATTRIBUTE_TIME_MODIFIED);
    time2 = g_file_info_get_attribute_uint64 (info2, G_FILE_ATTRIBUTE_TIME_MODIFIED);

    return time2 - time1;
}

static void
items_list_setup (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    //set items sort;
    gtk_list_box_set_sort_func (GTK_LIST_BOX (items_list),
                               (GtkListBoxSortFunc)items_sort_cb,
                               self,
                               NULL);
    priv->image_dir = g_file_new_for_path (IMAGE_DIR);
    g_file_enumerate_children_async (priv->image_dir,
                                     FILE_INFO_ATTRS,
                                     G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                     G_PRIORITY_DEFAULT,
                                     NULL,
                                     (GAsyncReadyCallback)enumerate_children_cb,
                                     self);
    gtk_list_box_set_activate_on_single_click (GTK_LIST_BOX (items_list), FALSE);
}

static void
menu_setup (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *menu_box = W (priv->builder, "menu-box");

    gint i;
    for (i = 0; menu_enties[i].entry_type < MENU_ENTRY_NONE; i++)
    {
        MenuEntry *entry = &menu_enties[i];
        GtkWidget *row = gtk_list_box_row_new ();
        gtk_container_add (GTK_CONTAINER (menu_box), row);
        if (entry->entry_type == MENU_ENTRY_REBOOT)
        {
            gtk_list_box_select_row (GTK_LIST_BOX (menu_box), GTK_LIST_BOX_ROW (row));
        }
        else if (entry->entry_type == MENU_ENTRY_SEPARATOR)
        {
            GtkWidget *separator = gtk_separator_new (GTK_ORIENTATION_HORIZONTAL);
            menu_entry_item_freeze (row);
            gtk_container_add (GTK_CONTAINER (row), separator);
            continue;
        }

        gchar *icon_file = g_strdup_printf ("%s/%s", DATA_DIR, entry->icon);
        GtkWidget *icon = gtk_image_new_from_file (icon_file);
        GtkWidget *label = gtk_label_new_with_mnemonic (gettext (entry->name));
        GtkWidget *row_box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
        gtk_widget_set_halign (row_box, GTK_ALIGN_START);

        gtk_container_add (GTK_CONTAINER (row_box), icon);
        gtk_container_add (GTK_CONTAINER (row_box), label);
        gtk_container_add (GTK_CONTAINER (row), row_box);
        g_object_set_data (G_OBJECT (row), "entry", entry);
        g_free (icon_file);
    }
    switch_to_menus (self);
}

static void
subtitle_update_datetime (NfsBackupRecovery *self, NfsImageItem *item)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    guint64 time;
    GDateTime *date_time;
    gchar *time_str, *subtitle;
    GtkWidget *widget = W (priv->builder, "subtitle-datetime");
    if (item == NULL)
    {
        gtk_widget_hide (widget);
        return ;
    }
    GFileInfo *file_info = nfs_image_item_get_file_info (NFS_IMAGE_ITEM (item));
    if (file_info)
    {
        time = g_file_info_get_attribute_uint64 (file_info, G_FILE_ATTRIBUTE_TIME_MODIFIED);
        date_time = g_date_time_new_from_unix_local (time);
        time_str = g_date_time_format (date_time, "%Y/%m/%d %H:%M");
        subtitle = g_strdup_printf (_("Last backup time：%s"), time_str);
        gtk_label_set_text (GTK_LABEL (widget), subtitle);

        gtk_widget_show (widget);
        g_date_time_unref (date_time);
        g_free (time_str);
        g_free (subtitle);
    } else {
        gtk_widget_hide (widget);
    }
}

static void
check_device_space (NfsBackupRecovery *self, gboolean show_notice)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    guint64     size, free;
    gfloat      size_f, free_f;
    gchar       *space_str, *subtitle;
    GFileInfo   *fs_info;
    GtkWidget   *widget;
    //GtkWidget   *backup_entry_item;

    widget = W (priv->builder, "subtitle-space");
    if (priv->fs_file == NULL)
    {
        priv->fs_file = g_file_new_for_path (FS_DIR);
    }

    fs_info = g_file_query_filesystem_info (priv->fs_file, FILE_SYSTEM_ATTRS, NULL, NULL);
    if (fs_info)
    {
        gtk_widget_show (widget);
        size = g_file_info_get_attribute_uint64 (fs_info, G_FILE_ATTRIBUTE_FILESYSTEM_SIZE);
        free = g_file_info_get_attribute_uint64 (fs_info, G_FILE_ATTRIBUTE_FILESYSTEM_FREE);
        size_f = (float)size/1024/1024/1024;
        free_f = (float)free/1024/1024/1024;
        space_str = g_strdup_printf ("%.1fGB / %.1fGB", free_f, size_f);
        subtitle = g_strdup_printf (_("Device space：%s"), space_str);
        gtk_label_set_text (GTK_LABEL (widget), subtitle);

        //backup_entry_item = menu_get_entry_item (self, MENU_ENTRY_BACKUP);
        if (free_f < DEVICE_FREE_SPACE_THRESHOLD)
        {
            priv->space_full = TRUE;
            if (show_notice)
            {
                notice_set_content (self, NOTICE_WARNING, _("Device space will be full, you'd better delete some useless images"));
            }
            // menu_entry_item_freeze (backup_entry_item);
        } else {
            priv->space_full = FALSE;
            // 不要清除，界面上可能有其他提示信息.
            // notice_set_content (self, NOTICE_NOMAL, NULL);
            // menu_entry_item_unfreeze (backup_entry_item);
        }

        g_free (subtitle);
        g_free (space_str);
        g_object_unref(fs_info);
    } else {
        gtk_widget_hide (widget);
    }
}

static void
check_log_space (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    guint64     free;
    GtkWidget   *reboot_entry_item;
    GFile       *gfile;
    GFileInfo   *fs_info;
    gfloat      free_f;

    gfile = g_file_new_for_path (FS_LOG_DIR);
    fs_info = g_file_query_filesystem_info (gfile, FILE_SYSTEM_ATTRS, NULL, NULL);
    if (fs_info)
    {
        free = g_file_info_get_attribute_uint64 (fs_info, G_FILE_ATTRIBUTE_FILESYSTEM_FREE);
        free_f = (float)free/1024/1024/1024;
        if (free_f < LOG_FREE_SPACE_THRESHOLD)
        {
            priv->log_space_full = TRUE;
            notice_set_content (self, NOTICE_WARNING, _("Log space will be full, you'd better clear it first."));
            freeze_all_menu_entries (self);
            reboot_entry_item = menu_get_entry_item (self, MENU_ENTRY_REBOOT);
            menu_entry_item_unfreeze (reboot_entry_item);
        } else {
            priv->log_space_full = FALSE;
        }
        g_object_unref(fs_info);
    }
    g_object_unref (gfile);
}
 
static void
menu_action_reboot (NfsBackupRecovery *self)
{
    gboolean res = FALSE;
    res = g_spawn_command_line_sync (COMMAND_REBOOT, NULL, NULL, NULL, NULL);
    menu_action_exit (res);
}

static void 
freeze_all_items(NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    GList *items, *rows;

    items = itemes_list_get_selected_rows (self, 0);
    if (items)
    {
        rows = items;
        while (rows != NULL)
        {
            GtkWidget *row = rows->data;
            menu_entry_item_freeze(row);
            rows = rows->next;
        }
        g_list_free (items);
    }
}

static void 
unfreeze_all_items (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    GList *items, *rows;

    items = itemes_list_get_selected_rows (self, 0);
    if (items)
    {
        rows = items;
        while (rows != NULL)
        {
            GtkWidget *row = rows->data;
            menu_entry_item_unfreeze(row);
            rows = rows->next;
        }
        g_list_free (items);
    }
}

static void
freeze_all_menu_entries (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GList *entry_items, *children;
    GtkWidget *menu_box;
    menu_box = W (priv->builder, "menu-box");
    entry_items = gtk_container_get_children (GTK_CONTAINER (menu_box));
    children = entry_items;
    while (children != NULL)
    {
        GtkWidget *item = children->data;
        if (g_object_get_data (item, "entry"))
        {
            menu_entry_item_freeze (item);
        }
        children = children->next;
    }
    g_list_free (entry_items);
}

static void
unfreeze_all_menu_entries (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GList *entry_items, *children;
    GtkWidget *menu_box;
    menu_box = W (priv->builder, "menu-box");
    entry_items = gtk_container_get_children (GTK_CONTAINER (menu_box));
    children = entry_items;
    while (children != NULL)
    {
        GtkWidget *item = children->data;
        if (g_object_get_data (item, "entry"))
        {
            menu_entry_item_unfreeze (item);
        }
        children = children->next;
    }
    g_list_free (entry_items);
}

static void 
set_notice_before_work(NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    MenuEntryType   cmd_type = priv->selected_entry_type;

    if (cmd_type == MENU_ENTRY_BACKUP)
        notice_set_content (self, NOTICE_NOMAL, _("System is being backed up, please wait ..."));
    else if (cmd_type == MENU_ENTRY_RECOVERY)
        notice_set_content (self, NOTICE_NOMAL, _("System is being restored, please wait ..."));
    else if (cmd_type == MENU_ENTRY_RESTORE_FACTORY_SETTINGS)
        notice_set_content (self, NOTICE_NOMAL, _("System is being restored to initial version, please wait ..."));
    else if (cmd_type == MENU_ENTRY_BACKUP_FACTORY_SETTINGS)
        notice_set_content (self, NOTICE_NOMAL, _("System is being backed up for the initial version, it will reboot when finishing, please wait ..."));
}

static gboolean 
delay_reboot (gpointer user_data)
{
    NfsBackupRecovery *self = (NfsBackupRecovery *)user_data;
    NfsBackupRecoveryPrivate *priv = self->priv;
    if (priv->timer < 1)
    {
        return G_SOURCE_REMOVE;
    }
    priv->timer -=1;
    gchar *notice = g_strdup_printf (_("System backing for the initial version finished, and will reboot in %d seconds."), priv->timer);
    notice_set_content (self, 
                        NOTICE_NOMAL, 
                        notice);
    g_free (notice);
    return G_SOURCE_CONTINUE;
}

static void 
set_notice_after_work (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    MenuEntryType   cmd_type = priv->selected_entry_type;
    gchar *failed_msg = NULL;

    if (!priv->cmd_result) {
        if (cmd_type == MENU_ENTRY_BACKUP)
        {
            notice_set_content (self, NOTICE_NOMAL, _("System backing finished, please reboot now."));
        }
        else if (cmd_type == MENU_ENTRY_RECOVERY)
            notice_set_content (self, NOTICE_NOMAL, _("System restoring finished, please reboot now."));
        else if (cmd_type == MENU_ENTRY_RESTORE_FACTORY_SETTINGS)
            notice_set_content (self, NOTICE_NOMAL, _("System restoring to initial version finished, please reboot now."));
        else if (cmd_type == MENU_ENTRY_BACKUP_FACTORY_SETTINGS)
        {
            priv->timer = 5;
            gchar *notice = g_strdup_printf (_("System backing for the initial version finished, and will reboot in %d seconds."), priv->timer);
            notice_set_content (self, 
                        NOTICE_NOMAL, 
                        notice);
            g_free (notice);
            g_timeout_add (1000, delay_reboot, self);
        }
    } else {
        if (cmd_type == MENU_ENTRY_BACKUP)
            failed_msg = g_strdup_printf (_("Failed to back up system, error code: %d."), priv->cmd_result);
        else if (cmd_type == MENU_ENTRY_RECOVERY)
            failed_msg = g_strdup_printf (_("Failed to restore system, error code: %d."), priv->cmd_result); 
        else if (cmd_type == MENU_ENTRY_RESTORE_FACTORY_SETTINGS)
            failed_msg = g_strdup_printf (_("Failed to restore system to initial version, error code: %d."), priv->cmd_result); 
        else if (cmd_type == MENU_ENTRY_BACKUP_FACTORY_SETTINGS)
            failed_msg = g_strdup_printf (_("Failed to bakcup system for initial version, error code: %d."), priv->cmd_result);
        if (failed_msg)
        {
            notice_set_content (self, NOTICE_NOMAL, failed_msg);
            g_free (failed_msg);
        }
        check_log_space (self);
    }
}

static void 
prepare_before_work (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *stack = W (priv->builder, "stack-content");
    const gchar *current;
    GtkWidget *button;
    current = gtk_stack_get_visible_child_name (GTK_STACK (stack));
    button = W (priv->builder, "button-reboot");
    gtk_widget_hide (button);
    if (g_strcmp0 (current, "menu") == 0)
    {
        //freenze all menu entries;
        freeze_all_menu_entries (self);
    } else {
        //freeze all items;
        GtkWidget *button = W (priv->builder, "button-apply");
        gtk_widget_set_sensitive(button, FALSE);

        button = W (priv->builder, "button-back");
        gtk_widget_set_sensitive(button, FALSE);

        freeze_all_items(self);
    }

    set_notice_before_work(self);
}


static void 
cleanup_after_work (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget   *entry_item;
    GtkWidget *button;
    priv->working = FALSE;
    if (priv->selected_entry_type == MENU_ENTRY_RECOVERY)
    {
        GtkWidget *button = W (priv->builder, "button-apply");
        gtk_widget_set_sensitive(button, TRUE);
        button = W (priv->builder, "button-back");
        gtk_widget_set_sensitive(button, TRUE);
        unfreeze_all_items(self);
    }
    if (priv->cmd_result == 0)
    {
        // 备份完成后，刷新列表
        if (priv->selected_entry_type == MENU_ENTRY_BACKUP)
        {
            items_list_update (self);
        }
        button = W (priv->builder, "button-reboot");
        gtk_widget_show (button);
        gtk_widget_grab_focus (button);
    }
    set_notice_after_work (self);
    if (priv->selected_entry_type != MENU_ENTRY_BACKUP_FACTORY_SETTINGS) {
        unfreeze_all_menu_entries (self);
        check_device_space(self, FALSE);
    } else {
        if (!priv->cmd_result)
            g_spawn_command_line_async (COMMAND_DELAY_REBOOT, NULL);
    }

}

static gboolean 
fill_progress_bar (gpointer   user_data)
{
    NfsBackupRecovery *self = (NfsBackupRecovery *)user_data;
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *progress_bar = W (priv->builder, "progress-bar");
    gchar text[20] = {0};

    gdouble fraction;
    fraction = gtk_progress_bar_get_fraction (GTK_PROGRESS_BAR (progress_bar));

    // 如果备份还原出错了，进度条结束.
    if (priv->cmd_finished && priv->cmd_result) 
    {
        cleanup_after_work (self);
        return FALSE;
    }

    // 正常情况下进度条的步进为0.01
    // 如果已经备份还原完了，加快步进到0.04
    // 如果进度条已经到90%了，但是还没有备份还原完，降低步进到0.002
    // 如果进度条已经到99%了，但是还没有备份还原完，进度条暂停
    if (priv->cmd_finished)
        fraction += 0.04;
    else if ((fraction >= 0.99) && !priv->cmd_finished)
        fraction += 0.0;
    else if ((fraction > 0.90) && !priv->cmd_finished)
        fraction += 0.002;
    else
        fraction += 0.01;

    if (fraction > 1.0)
       fraction = 1.0;

    sprintf(text, "%d %%", (int)(fraction * 100));
    gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
    gtk_progress_bar_set_text (GTK_PROGRESS_BAR (progress_bar), text);

    if (fraction < 1.0)
       return TRUE;

    cleanup_after_work (self);
    return FALSE;
}


static void 
do_backup_recover(gpointer data)
{
    NfsBackupRecoveryPrivate *priv = (NfsBackupRecoveryPrivate *)data;
    MenuEntryType   cmd_type = priv->selected_entry_type;
    char cmd[100] = {0};

    if (cmd_type == MENU_ENTRY_BACKUP)
        sprintf(cmd, "%s %s", COMMAND_BACKUP, priv->image);
    else if (cmd_type == MENU_ENTRY_RECOVERY)
        sprintf(cmd, "%s %s", COMMAND_RECOVERY, priv->image);
    else if (cmd_type == MENU_ENTRY_RESTORE_FACTORY_SETTINGS)
        sprintf(cmd, "%s %s", COMMAND_RESTORE_FACTORY_SETTINGS, priv->image);
    else if (cmd_type == MENU_ENTRY_BACKUP_FACTORY_SETTINGS)
        sprintf(cmd, "%s %s", COMMAND_BACKUP_FACTORY_SETTINGS, priv->image);
    priv->working = TRUE;
    priv->cmd_finished = 0;
    priv->cmd_result = system (cmd) >> 8;
    priv->cmd_finished = 1;

    g_free(priv->image);
    priv->image = NULL;
}

static void
menu_action_backup_factory_settings (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    gchar *image_name = NULL;

    gdouble fraction = 0.0;
    GtkWidget *progress_box = W (priv->builder, "progress-box");
    GtkWidget *progress_bar = W (priv->builder, "progress-bar");

    priv->selected_entry_type = MENU_ENTRY_BACKUP_FACTORY_SETTINGS;

    image_name = g_strdup_printf ("%s", IMAGE_FACTORY_SETTINGS);
    priv->image = image_name;
    priv->cmd_result = 0;
    priv->cmd_finished = 0;

    prepare_before_work (self);

    gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
    g_timeout_add (3000, fill_progress_bar, self);
    gtk_widget_show (progress_box);
    gtk_widget_show (progress_bar);

    g_thread_new ("initial-backup", (GThreadFunc)do_backup_recover, priv);
}

static void
menu_action_backup (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    gchar *image_name = NULL, *date_str = NULL;
    GDateTime *date = NULL;

    gdouble fraction = 0.0;
    GtkWidget *progress_box = W (priv->builder, "progress-box");
    GtkWidget *progress_bar = W (priv->builder, "progress-bar");

    check_device_space (self, TRUE);
    if (priv->space_full)
    {
        return ;
    }

    date = g_date_time_new_now_local ();
    date_str = g_date_time_format (date, "%Y%m%d%H%M%S");
    image_name = g_strdup_printf ("%s-%s", IMAGE_PREFIX, date_str);
    priv->image = image_name;
    priv->cmd_result = 0;
    priv->cmd_finished = 0;
    g_free (date_str);
    g_date_time_unref (date);

    prepare_before_work (self);

    gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
    g_timeout_add (3000, fill_progress_bar, self);
    gtk_widget_show (progress_box);

    g_thread_new ("backup", (GThreadFunc)do_backup_recover, priv);
}


static void
menu_action_restore_factory_settings (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *progress_box = W (priv->builder, "progress-box");
    GtkWidget *progress_bar = W (priv->builder, "progress-bar");
    gdouble fraction = 0.0;

    gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
    g_timeout_add (3000, fill_progress_bar, self);
    gtk_widget_show (progress_box);

    priv->image = strdup(IMAGE_FACTORY_SETTINGS);
    priv->cmd_result = 0;
    priv->cmd_finished = 0;

    prepare_before_work (self);

    g_thread_new("restore-to-initial-version", (GThreadFunc)do_backup_recover, priv);
}

static void
menu_action_recovery (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *button_apply = W (priv->builder, "button-apply");
    gtk_button_set_label (GTK_BUTTON (button_apply), _("Apply"));
    switch_to_items (self);
}

static void
menu_action_images_manage (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *button_apply = W (priv->builder, "button-apply");
    gtk_button_set_label (GTK_BUTTON (button_apply), _("Delete"));
    switch_to_items (self);
}

static void
menu_box_row_activated_cb (GtkListBox *box, GtkListBoxRow *row, gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);

    NfsBackupRecoveryPrivate *priv = self->priv;
    MenuEntry *entry = g_object_get_data (G_OBJECT (row), "entry");
    MenuEntryType entry_type = MENU_ENTRY_NONE;
    if (entry)
    {
        GtkWidget *progress_box = W (priv->builder, "progress-box");
        gtk_widget_hide (progress_box);
        notice_set_content (self, NOTICE_NOMAL, NULL);

        entry_type = entry->entry_type;
        priv->selected_entry_type = entry_type;
        switch (entry_type)
        {
            case MENU_ENTRY_REBOOT:
                menu_action_reboot (self);
                break;
            case MENU_ENTRY_BACKUP:
                menu_action_backup (self);
                break;
            case MENU_ENTRY_RECOVERY:
                menu_action_recovery (self);
                break;
            case MENU_ENTRY_IMAGES_MANAGE:
                menu_action_images_manage (self);
                break;
            case MENU_ENTRY_RESTORE_FACTORY_SETTINGS:
                confirm_dialog_run (self,
                                    _("Do you confirm restore factory settings?"),
                                    _("You will lose some files and applications after restore."));
                break;
            default:
                break;
        }
    }
}

static GList *
itemes_list_get_selected_rows (NfsBackupRecovery *self, int flag)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *items_list = W (priv->builder, "items-list");
    GList *items, *selected = NULL, *children;
    children = gtk_container_get_children (GTK_CONTAINER (items_list));
    items = children;
    while (items != NULL)
    {
        GtkWidget *item = items->data;
        if (flag) {
            if (nfs_image_item_is_selected (NFS_IMAGE_ITEM (item)))
            {
                selected = g_list_append (selected, item);
            }
        } else {
                selected = g_list_append (selected, item);
        }
        items = items->next;
    }
    g_list_free (children);
    return selected;
}

static void
items_list_selected_rows_changed_cb (GtkListBox *box, gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    GList *selected = NULL;
    guint len = 0;
    GtkWidget *button = NULL;

    button = W (priv->builder, "button-apply");

    selected = itemes_list_get_selected_rows (self, 1);
    len = g_list_length (selected);
    if (len)
    {
        gtk_widget_set_sensitive (button, TRUE);
    } else {
        gtk_widget_set_sensitive (button, FALSE);
    }

    g_list_free (selected);
}

static void
items_list_row_activated_cb (GtkListBox *box, GtkListBoxRow *row, gpointer user_data)
{
    nfs_image_item_select_toggle (NFS_IMAGE_ITEM (row));
}

static gchar *
syslog_format_string ()
{
    GDateTime *date;
    gchar *date_str;
    date = g_date_time_new_now_local ();
    date_str = g_date_time_format (date, "%b %d %H:%M:%S localhost BackupRecover[9999]:");
    return date_str;
}

static gchar *
syslog_message_cmd (gchar *text)
{
    gchar *cmd;
    gchar *date_str = syslog_format_string ();
    cmd = g_strdup_printf ("echo \"%s %s\" >> /media/messages", date_str, text);
    g_free (date_str);
    return cmd;
}

static void
items_list_delete_selected (NfsBackupRecovery *self)
{
    char *cmd = NULL;
    gchar *log_cmd = NULL;
    gchar *log_text = NULL;
    gchar *file_path;
    int res = 0;
    GFile *file;
    GList *rows, *selected_rows;
    selected_rows = itemes_list_get_selected_rows (self, 1);
    if (selected_rows)
    {
        rows = selected_rows;
        while (rows != NULL)
        {
            GtkWidget *row = rows->data;
            file = nfs_image_item_get_file (NFS_IMAGE_ITEM (row));
            file_path = g_file_get_path (file);
            cmd = (char *)malloc(strlen(file_path) + 15);
            if (cmd) {
                sprintf (cmd, "rm -rf '%s'", file_path);
                res = system (cmd);
                free (cmd);
                // log start
                if (res == 0) {
                    log_text = g_strdup_printf ("delete image %s success", file_path);
                } else {
                    log_text = g_strdup_printf ("delete image %s failed", file_path);
                }
                log_cmd = syslog_message_cmd (log_text);
                system(log_cmd);
                g_free (log_cmd);
                g_free (log_text);
            }
            g_free (file_path);
            rows = rows->next;
        }
        g_list_free (selected_rows);
        items_list_update (self);
        check_device_space (self, FALSE);
    }
}

static void
items_list_recovery_selected (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv = self->priv;
    GList *selected;
    GtkListBoxRow *row;
    GFileInfo *file_info;
    const gchar *image_name;

    selected = itemes_list_get_selected_rows (self, 1);
    if (!selected)
    {
        return ;
    }
    //selected list only one child.
    row = selected->data;
    if (row)
    {
        file_info = nfs_image_item_get_file_info (NFS_IMAGE_ITEM (row));
        image_name = strdup(g_file_info_get_display_name (file_info));

        gdouble fraction = 0.0;
        GtkWidget *progress_box = W (priv->builder, "progress-box");
        GtkWidget *progress_bar = W (priv->builder, "progress-bar");

        priv->image = image_name;
        priv->cmd_result = 0;
        priv->cmd_finished = 0;

        prepare_before_work (self);

        gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), fraction);
        g_timeout_add (3000, fill_progress_bar, self);
        gtk_widget_show (progress_box);

        g_thread_new ("recover", (GThreadFunc)do_backup_recover, priv);

        g_list_free (selected);
    }
}

static void
button_apply_clicked_cb (GtkButton *widget, gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    if (priv->selected_entry_type == MENU_ENTRY_IMAGES_MANAGE)
    {
        items_list_delete_selected (self);
    }
    else if (priv->selected_entry_type == MENU_ENTRY_RECOVERY)
    {
        items_list_recovery_selected (self);
    }
}

static void
button_back_clicked_cb (GtkButton *widget, gpointer user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    //NfsBackupRecoveryPrivate *priv = self->priv;
    switch_to_menus (self);
}

static gboolean
main_window_key_release_event_cb (GtkWidget *widget,
                                  GdkEvent  *event,
                                  gpointer   user_data)
{
    NfsBackupRecovery *self = NFS_BACKUP_RECOVERY (user_data);
    NfsBackupRecoveryPrivate *priv = self->priv;
    guint keyval;
    gdk_event_get_keyval (event, &keyval);
    if (keyval == GDK_KEY_Escape && priv->working == FALSE)
    {
        if (priv->selected_entry_type == MENU_ENTRY_IMAGES_MANAGE)
        {
            GtkWidget *items_list = W (priv->builder, "items-list");
            GtkListBoxRow *selected_row = gtk_list_box_get_selected_row (GTK_LIST_BOX (items_list));
            if (selected_row && nfs_image_item_is_editing (NFS_IMAGE_ITEM (selected_row)))
            {
                gtk_widget_grab_focus (GTK_WIDGET (selected_row));
                return FALSE;
            }
        }
        if (priv->selected_entry_type == MENU_ENTRY_RECOVERY ||
            priv->selected_entry_type == MENU_ENTRY_IMAGES_MANAGE)
        {
            switch_to_menus (self);
        }
    }
    return FALSE;
}

static void
button_reboot_clicked_cb (GtkWidget *button, gpointer user_data)
{
    menu_action_reboot (NFS_BACKUP_RECOVERY (user_data));
}

static void
nfs_backup_recovery_init (NfsBackupRecovery *self)
{
    NfsBackupRecoveryPrivate *priv;
    priv = self->priv = NFS_BACKUP_RECOVERY_GET_PRIVATE (self);
    GError *error = NULL;

    priv->builder = gtk_builder_new ();
    if (!gtk_builder_add_from_file (priv->builder, DATA_DIR "/main.ui", &error))
    {
        g_error ("Could not build interface ui from file: %s.\n", error->message);
        g_error_free (error);
        return;
    }

    priv->working = FALSE;
    priv->log_space_full = FALSE;
    GtkWidget *items_list = W (priv->builder, "items-list");

    menu_setup (self);

    gtk_builder_add_callback_symbols (priv->builder,
                                      "menu_box_row_activated_cb", G_CALLBACK (menu_box_row_activated_cb),
                                      "items_list_row_activated_cb", G_CALLBACK (items_list_row_activated_cb),
                                      "button_apply_clicked_cb", G_CALLBACK (button_apply_clicked_cb),
                                      "button_back_clicked_cb", G_CALLBACK (button_back_clicked_cb),
                                      "items_list_selected_rows_changed_cb", G_CALLBACK (items_list_selected_rows_changed_cb),
                                      "main_window_key_release_event_cb", G_CALLBACK (main_window_key_release_event_cb),
                                      "button_reboot_clicked_cb", G_CALLBACK (button_reboot_clicked_cb),
                                      NULL);
    gtk_builder_connect_signals (priv->builder, self);
    items_list_update (self);
    check_device_space (self, TRUE);
    items_list_selected_rows_changed_cb (GTK_LIST_BOX (items_list), self);
}

static void
app_set_window (NfsBackupRecovery *self, GtkApplication * app)
{
    char init_image[50] = {0};
    NfsBackupRecoveryPrivate *priv = self->priv;
    GtkWidget *window = W (priv->builder, "main-window");
    GtkWidget *progress_box = W (priv->builder, "progress-box");
    priv->application = app;
    priv->window = window;
    gtk_window_set_keep_above (GTK_WINDOW (priv->window), TRUE);

    gtk_application_add_window (priv->application, GTK_WINDOW (window));
    gtk_widget_show_all (window);
    gtk_widget_hide (progress_box);

    gtk_window_fullscreen (GTK_WINDOW(window));
    gtk_window_set_hide_titlebar_when_maximized (window, TRUE);

    sprintf(init_image, "%s/%s", IMAGE_DIR, IMAGE_FACTORY_SETTINGS);
    if (access(init_image, F_OK))
        menu_action_backup_factory_settings (self);
}

static void
nfs_backup_recovery_class_init (NfsBackupRecoveryClass *klass)
{

    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);
    g_type_class_add_private (klass, sizeof (NfsBackupRecoveryPrivate));

    gobject_class->dispose = nfs_backup_recovery_dispose;
    gobject_class->finalize = nfs_backup_recovery_finalize;
}

static void
nfs_backup_recovery_dispose (GObject *object)
{
    NfsBackupRecoveryPrivate *priv = NFS_BACKUP_RECOVERY (object)->priv;
    if (priv->dialog_window)
    {
        gtk_widget_destroy (priv->dialog_window);
        priv->dialog_window = NULL;
    }
    g_clear_object (&priv->image_dir);
    g_clear_object (&priv->enumerator);
    g_clear_object (&priv->builder);
    g_clear_object (&priv->fs_file);
    G_OBJECT_CLASS (nfs_backup_recovery_parent_class)->dispose (object);
}

static void
nfs_backup_recovery_finalize (GObject *object)
{
    NfsBackupRecoveryPrivate *priv = NFS_BACKUP_RECOVERY (object)->priv;
    if (priv->image)
    {
        g_free (priv->image);
    }
    G_OBJECT_CLASS (nfs_backup_recovery_parent_class)->finalize (object);
}

NfsBackupRecovery *
nfs_backup_recovery_run (GtkApplication * app)
{
    if (backup_recovery == NULL)
    {
        backup_recovery = g_object_new (NFS_TYPE_BACKUP_RECOVERY, NULL);
        app_set_window (backup_recovery, app);
    }
    return backup_recovery;
}

void
nfs_backup_recovery_set_notice (NoticeType notice_type, gchar *notice)
{
    if (backup_recovery)
    {
        notice_set_content (backup_recovery, notice_type, notice);
    }
}
