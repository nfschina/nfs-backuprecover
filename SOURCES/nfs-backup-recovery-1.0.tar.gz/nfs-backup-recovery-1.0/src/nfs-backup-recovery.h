//
// Created by zhangtao on 19-12-12.
// Email: zhangtao@cpu-os.ac.cn
//

#ifndef __NFS_BACKUP_RECOVERY_H__
#define __NFS_BACKUP_RECOVERY_H__

#include "nfs-backup-recovery-private.h"
#include <glib-object.h>
#include <gtk/gtk.h>

#define NFS_TYPE_BACKUP_RECOVERY (nfs_backup_recovery_get_type())
#define NFS_BACKUP_RECOVERY(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),NFS_TYPE_BACKUP_RECOVERY,NfsBackupRecovery))
#define NFS_IS_BACKUP_RECOVERY(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj),NFS_TYPE_BACKUP_RECOVERY))
#define NFS_BACKUP_RECOVERY_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST((klass),NFS_TYPE_BACKUP_RECOVERY,NfsBackupRecoveryClass))
#define NFS_IS_BACKUP_RECOVERY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((obj),NFS_TYPE_BACKUP_RECOVERY))
#define NFS_BACKUP_RECOVERY_GET_CLASS(obj) (G_TYPE_INSTANCE_GET_CLASS((obj),CDOS_TYPE_BACKUP_RECOVERY,NfsBackupRecoveryClass))

typedef struct _NfsBackupRecovery NfsBackupRecovery;
typedef struct _NfsBackupRecoveryPrivate NfsBackupRecoveryPrivate;
typedef struct _NfsBackupRecoveryClass NfsBackupRecoveryClass;

struct _NfsBackupRecovery
{
    GObject parent;
    NfsBackupRecoveryPrivate *priv;
};
struct _NfsBackupRecoveryClass
{
    GObjectClass parent_class;
};

GType	nfs_backup_recovery_get_type (void);
NfsBackupRecovery *
nfs_backup_recovery_run (GtkApplication * app);

#endif //__NFS_BACKUP_RECOVERY_H__
