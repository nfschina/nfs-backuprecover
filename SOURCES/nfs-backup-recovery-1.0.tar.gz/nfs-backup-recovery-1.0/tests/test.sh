#!/bin/sh
srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.
testdir=$(cd "$(dirname "$0")"; pwd)

cmd=$srcdir/../src/nemo-print
resource=$srcdir/resource

uri="file://$testdir/resource/"
files=""

if test -e $cmd
then
    for f in `ls $resource`
    do
        files="$files $uri$f"
    done
    $cmd $files
fi